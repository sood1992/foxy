<?php
// check_api_status.php - Check which AI APIs are configured and available
header('Content-Type: application/json');

// Your configured API keys
$googleVisionApiKey = 'AIzaSyASXSmZjGtx5r6dOMQ_TXQUDVfpx9nryRU';
$openaiApiKey = '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';

$status = [
    'google_vision' => true,  // Your Google Vision API is configured
    'openai_vision' => true,  // Your OpenAI API is configured  
    'fallback' => false      // Fallback disabled - only real AI results
];

echo json_encode($status);
?>